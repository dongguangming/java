interface Stack {
    public boolean empty();
    public void push(Object elt);
    public Object pop();
}
