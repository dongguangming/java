import java.util.*;

class Stacks {
    public static <E> Stack<E> reverse(Stack<E> in) {
	throw new StubException();
    }
}

