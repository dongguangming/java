package com.packt.sfjd.ch2;

public class MyInterfaceDemo {
public static void main(String[] args) {
	System.out.println();
	MyInterfaceImpl obj =new MyInterfaceImpl();
	obj.hello(); // wont-complie
}
}
