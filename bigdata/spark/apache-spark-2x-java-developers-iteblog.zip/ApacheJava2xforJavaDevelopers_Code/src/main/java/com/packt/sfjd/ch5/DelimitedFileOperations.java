package com.packt.sfjd.ch5;

public class DelimitedFileOperations {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
