package com.packt.sfjd.ch2;

public interface Interface2 {
	default void hello(){
		System.out.println("Hello from Interface1");
	}
}
