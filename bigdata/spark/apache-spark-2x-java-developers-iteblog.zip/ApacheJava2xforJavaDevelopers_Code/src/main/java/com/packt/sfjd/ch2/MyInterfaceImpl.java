package com.packt.sfjd.ch2;

public class MyInterfaceImpl implements MyInterface{

	@Override
	public void absmethod() {
		System.out.println("Abstract method implementaion in class");		
	}
	
}
