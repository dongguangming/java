package com.packt.sfjd.ch2;

//@FunctionalInterface
public interface Interface1 {

	default void hello(){
		System.out.println("Hello from Interface1");
	}
	
	//void method1();
	
}
